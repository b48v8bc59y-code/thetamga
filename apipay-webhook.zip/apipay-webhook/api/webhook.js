const crypto = require('crypto');

// Vercel нужно сырое тело для проверки подписи
export const config = {
  api: {
    bodyParser: false,
  },
};

// Читаем сырое тело запроса
async function getRawBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => { data += chunk; });
    req.on('end', () => resolve(data));
    req.on('error', reject);
  });
}

// Помечаем заказ Shopify как оплаченный
async function markShopifyOrderPaid(orderId, amount) {
  const SHOPIFY_STORE = process.env.SHOPIFY_STORE; // например: thetamga.com
  const SHOPIFY_TOKEN = process.env.SHOPIFY_ACCESS_TOKEN;

  const url = `https://${SHOPIFY_STORE}/admin/api/2024-01/orders/${orderId}/transactions.json`;

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Shopify-Access-Token': SHOPIFY_TOKEN,
    },
    body: JSON.stringify({
      transaction: {
        kind: 'capture',
        status: 'success',
        amount: amount,
        gateway: 'Kaspi Pay (ApiPay.kz)',
      }
    })
  });

  if (!response.ok) {
    const error = await response.text();
    console.error(`Shopify error for order ${orderId}:`, error);
    throw new Error(`Shopify API error: ${error}`);
  }

  console.log(`✅ Заказ ${orderId} помечен как оплаченный на сумму ${amount}₸`);
  return await response.json();
}

export default async function handler(req, res) {
  // Только POST запросы
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  let rawBody;
  try {
    rawBody = await getRawBody(req);
  } catch (err) {
    console.error('Ошибка чтения тела:', err);
    return res.status(400).json({ error: 'Cannot read body' });
  }

  // Проверяем подпись от ApiPay
  const signature = req.headers['x-webhook-signature'];
  const secret = process.env.APIPAY_WEBHOOK_SECRET;

  if (!signature || !secret) {
    console.error('Подпись или секрет отсутствуют');
    return res.status(401).json({ error: 'Missing signature' });
  }

  const expected = 'sha256=' + crypto
    .createHmac('sha256', secret)
    .update(rawBody)
    .digest('hex');

  const signaturesMatch = crypto.timingSafeEqual(
    Buffer.from(expected),
    Buffer.from(signature)
  );

  if (!signaturesMatch) {
    console.error('Подпись не совпадает');
    return res.status(401).json({ error: 'Invalid signature' });
  }

  // Парсим тело
  let payload;
  try {
    payload = JSON.parse(rawBody);
  } catch (err) {
    return res.status(400).json({ error: 'Invalid JSON' });
  }

  const { event, invoice } = payload;

  console.log(`Получено событие: ${event}`, invoice);

  // Тестовое событие от ApiPay — просто подтверждаем
  if (event === 'webhook.test') {
    console.log('✅ Тестовый вебхук получен успешно');
    return res.status(200).json({ ok: true, message: 'Test webhook received' });
  }

  // Оплата подтверждена
  if (event === 'invoice.status_changed' && invoice?.status === 'paid') {
    const shopifyOrderId = invoice.external_order_id;

    if (!shopifyOrderId) {
      console.warn('external_order_id не указан в счёте');
      return res.status(200).json({ ok: true, warning: 'No order ID' });
    }

    try {
      await markShopifyOrderPaid(shopifyOrderId, invoice.amount);
    } catch (err) {
      console.error('Ошибка обновления заказа:', err.message);
      // Возвращаем 200 чтобы ApiPay не повторял попытки зря
      return res.status(200).json({ ok: false, error: err.message });
    }
  }

  // Возврат
  if (event === 'invoice.refunded') {
    console.log(`↩️ Возврат по заказу ${invoice?.external_order_id}`);
    // Здесь можно добавить логику возврата в Shopify
  }

  return res.status(200).json({ ok: true });
}
